
# coding: utf-8

# # Test cells

# In[ ]:


assert callable(is_in_list)
assert callable(end_chat)
assert callable(selector)
assert isinstance(is_question(['what?']), bool)

